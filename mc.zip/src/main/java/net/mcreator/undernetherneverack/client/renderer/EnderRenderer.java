
package net.mcreator.undernetherneverack.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.SlimeModel;

import net.mcreator.undernetherneverack.entity.EnderEntity;

public class EnderRenderer extends MobRenderer<EnderEntity, SlimeModel<EnderEntity>> {
	public EnderRenderer(EntityRendererProvider.Context context) {
		super(context, new SlimeModel(context.bakeLayer(ModelLayers.SLIME)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(EnderEntity entity) {
		return new ResourceLocation("under_nether_neverack:textures/entities/slime-planetminecraft-com-13882550.png");
	}
}
