
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.undernetherneverack.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.undernetherneverack.item.Yellow_saphireSwordItem;
import net.mcreator.undernetherneverack.item.Yellow_saphireShovelItem;
import net.mcreator.undernetherneverack.item.Yellow_saphirePickaxeItem;
import net.mcreator.undernetherneverack.item.Yellow_saphireItem;
import net.mcreator.undernetherneverack.item.Yellow_saphireHoeItem;
import net.mcreator.undernetherneverack.item.Yellow_saphireAxeItem;
import net.mcreator.undernetherneverack.item.Yellow_saphireArmorItem;
import net.mcreator.undernetherneverack.item.SaphirSwordItem;
import net.mcreator.undernetherneverack.item.SaphirShovelItem;
import net.mcreator.undernetherneverack.item.SaphirPickaxeItem;
import net.mcreator.undernetherneverack.item.SaphirItem;
import net.mcreator.undernetherneverack.item.SaphirHoeItem;
import net.mcreator.undernetherneverack.item.SaphirAxeItem;
import net.mcreator.undernetherneverack.item.SaphirArmorItem;
import net.mcreator.undernetherneverack.item.RubySwordItem;
import net.mcreator.undernetherneverack.item.RubyShovelItem;
import net.mcreator.undernetherneverack.item.RubyPickaxeItem;
import net.mcreator.undernetherneverack.item.RubyItem;
import net.mcreator.undernetherneverack.item.RubyHoeItem;
import net.mcreator.undernetherneverack.item.RubyAxeItem;
import net.mcreator.undernetherneverack.item.RubyArmorItem;
import net.mcreator.undernetherneverack.item.EmeraldsSwordItem;
import net.mcreator.undernetherneverack.item.EmeraldsShovelItem;
import net.mcreator.undernetherneverack.item.EmeraldsPickaxeItem;
import net.mcreator.undernetherneverack.item.EmeraldsHoeItem;
import net.mcreator.undernetherneverack.item.EmeraldsAxeItem;
import net.mcreator.undernetherneverack.item.EmeraldsArmorItem;
import net.mcreator.undernetherneverack.item.CoraleumSwordItem;
import net.mcreator.undernetherneverack.item.CoraleumShovelItem;
import net.mcreator.undernetherneverack.item.CoraleumPickaxeItem;
import net.mcreator.undernetherneverack.item.CoraleumHoeItem;
import net.mcreator.undernetherneverack.item.CoraleumDustItem;
import net.mcreator.undernetherneverack.item.CoraleumAxeItem;
import net.mcreator.undernetherneverack.item.CoraleumArmorItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaSwordItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaShovelItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaPickaxeItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaHoeItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaAxeItem;
import net.mcreator.undernetherneverack.item.Aigue_marinaArmorItem;
import net.mcreator.undernetherneverack.item.AgruliteSwordItem;
import net.mcreator.undernetherneverack.item.AgruliteShovelItem;
import net.mcreator.undernetherneverack.item.AgrulitePickaxeItem;
import net.mcreator.undernetherneverack.item.AgruliteIngotItem;
import net.mcreator.undernetherneverack.item.AgruliteHoeItem;
import net.mcreator.undernetherneverack.item.AgruliteAxeItem;
import net.mcreator.undernetherneverack.item.AgruliteArmorItem;
import net.mcreator.undernetherneverack.UnderNetherNeverackMod;

public class UnderNetherNeverackModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, UnderNetherNeverackMod.MODID);
	public static final RegistryObject<Item> SAPHIR = REGISTRY.register("saphir", () -> new SaphirItem());
	public static final RegistryObject<Item> SAPHIR_ORE = block(UnderNetherNeverackModBlocks.SAPHIR_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SAPHIR_BLOCK = block(UnderNetherNeverackModBlocks.SAPHIR_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> SAPHIR_PICKAXE = REGISTRY.register("saphir_pickaxe", () -> new SaphirPickaxeItem());
	public static final RegistryObject<Item> SAPHIR_AXE = REGISTRY.register("saphir_axe", () -> new SaphirAxeItem());
	public static final RegistryObject<Item> SAPHIR_SWORD = REGISTRY.register("saphir_sword", () -> new SaphirSwordItem());
	public static final RegistryObject<Item> SAPHIR_SHOVEL = REGISTRY.register("saphir_shovel", () -> new SaphirShovelItem());
	public static final RegistryObject<Item> SAPHIR_HOE = REGISTRY.register("saphir_hoe", () -> new SaphirHoeItem());
	public static final RegistryObject<Item> SAPHIR_ARMOR_HELMET = REGISTRY.register("saphir_armor_helmet", () -> new SaphirArmorItem.Helmet());
	public static final RegistryObject<Item> SAPHIR_ARMOR_CHESTPLATE = REGISTRY.register("saphir_armor_chestplate",
			() -> new SaphirArmorItem.Chestplate());
	public static final RegistryObject<Item> SAPHIR_ARMOR_LEGGINGS = REGISTRY.register("saphir_armor_leggings", () -> new SaphirArmorItem.Leggings());
	public static final RegistryObject<Item> SAPHIR_ARMOR_BOOTS = REGISTRY.register("saphir_armor_boots", () -> new SaphirArmorItem.Boots());
	public static final RegistryObject<Item> RUBY = REGISTRY.register("ruby", () -> new RubyItem());
	public static final RegistryObject<Item> RUBY_ORE = block(UnderNetherNeverackModBlocks.RUBY_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RUBY_BLOCK = block(UnderNetherNeverackModBlocks.RUBY_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> RUBY_PICKAXE = REGISTRY.register("ruby_pickaxe", () -> new RubyPickaxeItem());
	public static final RegistryObject<Item> RUBY_AXE = REGISTRY.register("ruby_axe", () -> new RubyAxeItem());
	public static final RegistryObject<Item> RUBY_SWORD = REGISTRY.register("ruby_sword", () -> new RubySwordItem());
	public static final RegistryObject<Item> RUBY_SHOVEL = REGISTRY.register("ruby_shovel", () -> new RubyShovelItem());
	public static final RegistryObject<Item> RUBY_HOE = REGISTRY.register("ruby_hoe", () -> new RubyHoeItem());
	public static final RegistryObject<Item> RUBY_ARMOR_HELMET = REGISTRY.register("ruby_armor_helmet", () -> new RubyArmorItem.Helmet());
	public static final RegistryObject<Item> RUBY_ARMOR_CHESTPLATE = REGISTRY.register("ruby_armor_chestplate", () -> new RubyArmorItem.Chestplate());
	public static final RegistryObject<Item> RUBY_ARMOR_LEGGINGS = REGISTRY.register("ruby_armor_leggings", () -> new RubyArmorItem.Leggings());
	public static final RegistryObject<Item> RUBY_ARMOR_BOOTS = REGISTRY.register("ruby_armor_boots", () -> new RubyArmorItem.Boots());
	public static final RegistryObject<Item> EMERALDS_PICKAXE = REGISTRY.register("emeralds_pickaxe", () -> new EmeraldsPickaxeItem());
	public static final RegistryObject<Item> EMERALDS_AXE = REGISTRY.register("emeralds_axe", () -> new EmeraldsAxeItem());
	public static final RegistryObject<Item> EMERALDS_SWORD = REGISTRY.register("emeralds_sword", () -> new EmeraldsSwordItem());
	public static final RegistryObject<Item> EMERALDS_SHOVEL = REGISTRY.register("emeralds_shovel", () -> new EmeraldsShovelItem());
	public static final RegistryObject<Item> EMERALDS_HOE = REGISTRY.register("emeralds_hoe", () -> new EmeraldsHoeItem());
	public static final RegistryObject<Item> EMERALDS_ARMOR_HELMET = REGISTRY.register("emeralds_armor_helmet", () -> new EmeraldsArmorItem.Helmet());
	public static final RegistryObject<Item> EMERALDS_ARMOR_CHESTPLATE = REGISTRY.register("emeralds_armor_chestplate",
			() -> new EmeraldsArmorItem.Chestplate());
	public static final RegistryObject<Item> EMERALDS_ARMOR_LEGGINGS = REGISTRY.register("emeralds_armor_leggings",
			() -> new EmeraldsArmorItem.Leggings());
	public static final RegistryObject<Item> EMERALDS_ARMOR_BOOTS = REGISTRY.register("emeralds_armor_boots", () -> new EmeraldsArmorItem.Boots());
	public static final RegistryObject<Item> YELLOW_SAPHIRE = REGISTRY.register("yellow_saphire", () -> new Yellow_saphireItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_ORE = block(UnderNetherNeverackModBlocks.YELLOW_SAPHIRE_ORE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> YELLOW_SAPHIRE_BLOCK = block(UnderNetherNeverackModBlocks.YELLOW_SAPHIRE_BLOCK,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> YELLOW_SAPHIRE_PICKAXE = REGISTRY.register("yellow_saphire_pickaxe",
			() -> new Yellow_saphirePickaxeItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_AXE = REGISTRY.register("yellow_saphire_axe", () -> new Yellow_saphireAxeItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_SWORD = REGISTRY.register("yellow_saphire_sword", () -> new Yellow_saphireSwordItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_SHOVEL = REGISTRY.register("yellow_saphire_shovel", () -> new Yellow_saphireShovelItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_HOE = REGISTRY.register("yellow_saphire_hoe", () -> new Yellow_saphireHoeItem());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_ARMOR_HELMET = REGISTRY.register("yellow_saphire_armor_helmet",
			() -> new Yellow_saphireArmorItem.Helmet());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_ARMOR_CHESTPLATE = REGISTRY.register("yellow_saphire_armor_chestplate",
			() -> new Yellow_saphireArmorItem.Chestplate());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_ARMOR_LEGGINGS = REGISTRY.register("yellow_saphire_armor_leggings",
			() -> new Yellow_saphireArmorItem.Leggings());
	public static final RegistryObject<Item> YELLOW_SAPHIRE_ARMOR_BOOTS = REGISTRY.register("yellow_saphire_armor_boots",
			() -> new Yellow_saphireArmorItem.Boots());
	public static final RegistryObject<Item> AIGUE_MARINA = REGISTRY.register("aigue_marina", () -> new Aigue_marinaItem());
	public static final RegistryObject<Item> AIGUE_MARINA_ORE = block(UnderNetherNeverackModBlocks.AIGUE_MARINA_ORE,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> AIGUE_MARINA_BLOCK = block(UnderNetherNeverackModBlocks.AIGUE_MARINA_BLOCK,
			CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> AIGUE_MARINA_PICKAXE = REGISTRY.register("aigue_marina_pickaxe", () -> new Aigue_marinaPickaxeItem());
	public static final RegistryObject<Item> AIGUE_MARINA_AXE = REGISTRY.register("aigue_marina_axe", () -> new Aigue_marinaAxeItem());
	public static final RegistryObject<Item> AIGUE_MARINA_SWORD = REGISTRY.register("aigue_marina_sword", () -> new Aigue_marinaSwordItem());
	public static final RegistryObject<Item> AIGUE_MARINA_SHOVEL = REGISTRY.register("aigue_marina_shovel", () -> new Aigue_marinaShovelItem());
	public static final RegistryObject<Item> AIGUE_MARINA_HOE = REGISTRY.register("aigue_marina_hoe", () -> new Aigue_marinaHoeItem());
	public static final RegistryObject<Item> AIGUE_MARINA_ARMOR_HELMET = REGISTRY.register("aigue_marina_armor_helmet",
			() -> new Aigue_marinaArmorItem.Helmet());
	public static final RegistryObject<Item> AIGUE_MARINA_ARMOR_CHESTPLATE = REGISTRY.register("aigue_marina_armor_chestplate",
			() -> new Aigue_marinaArmorItem.Chestplate());
	public static final RegistryObject<Item> AIGUE_MARINA_ARMOR_LEGGINGS = REGISTRY.register("aigue_marina_armor_leggings",
			() -> new Aigue_marinaArmorItem.Leggings());
	public static final RegistryObject<Item> AIGUE_MARINA_ARMOR_BOOTS = REGISTRY.register("aigue_marina_armor_boots",
			() -> new Aigue_marinaArmorItem.Boots());
	public static final RegistryObject<Item> CORALEUM_DUST = REGISTRY.register("coraleum_dust", () -> new CoraleumDustItem());
	public static final RegistryObject<Item> CORALEUM_ORE = block(UnderNetherNeverackModBlocks.CORALEUM_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> CORALEUM_BLOCK = block(UnderNetherNeverackModBlocks.CORALEUM_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> CORALEUM_PICKAXE = REGISTRY.register("coraleum_pickaxe", () -> new CoraleumPickaxeItem());
	public static final RegistryObject<Item> CORALEUM_AXE = REGISTRY.register("coraleum_axe", () -> new CoraleumAxeItem());
	public static final RegistryObject<Item> CORALEUM_SWORD = REGISTRY.register("coraleum_sword", () -> new CoraleumSwordItem());
	public static final RegistryObject<Item> CORALEUM_SHOVEL = REGISTRY.register("coraleum_shovel", () -> new CoraleumShovelItem());
	public static final RegistryObject<Item> CORALEUM_HOE = REGISTRY.register("coraleum_hoe", () -> new CoraleumHoeItem());
	public static final RegistryObject<Item> CORALEUM_ARMOR_HELMET = REGISTRY.register("coraleum_armor_helmet", () -> new CoraleumArmorItem.Helmet());
	public static final RegistryObject<Item> CORALEUM_ARMOR_CHESTPLATE = REGISTRY.register("coraleum_armor_chestplate",
			() -> new CoraleumArmorItem.Chestplate());
	public static final RegistryObject<Item> CORALEUM_ARMOR_LEGGINGS = REGISTRY.register("coraleum_armor_leggings",
			() -> new CoraleumArmorItem.Leggings());
	public static final RegistryObject<Item> CORALEUM_ARMOR_BOOTS = REGISTRY.register("coraleum_armor_boots", () -> new CoraleumArmorItem.Boots());
	public static final RegistryObject<Item> AGRULITE_INGOT = REGISTRY.register("agrulite_ingot", () -> new AgruliteIngotItem());
	public static final RegistryObject<Item> AGRULITE_ORE = block(UnderNetherNeverackModBlocks.AGRULITE_ORE, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> AGRULITE_BLOCK = block(UnderNetherNeverackModBlocks.AGRULITE_BLOCK, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> AGRULITE_PICKAXE = REGISTRY.register("agrulite_pickaxe", () -> new AgrulitePickaxeItem());
	public static final RegistryObject<Item> AGRULITE_AXE = REGISTRY.register("agrulite_axe", () -> new AgruliteAxeItem());
	public static final RegistryObject<Item> AGRULITE_SWORD = REGISTRY.register("agrulite_sword", () -> new AgruliteSwordItem());
	public static final RegistryObject<Item> AGRULITE_SHOVEL = REGISTRY.register("agrulite_shovel", () -> new AgruliteShovelItem());
	public static final RegistryObject<Item> AGRULITE_HOE = REGISTRY.register("agrulite_hoe", () -> new AgruliteHoeItem());
	public static final RegistryObject<Item> AGRULITE_ARMOR_HELMET = REGISTRY.register("agrulite_armor_helmet", () -> new AgruliteArmorItem.Helmet());
	public static final RegistryObject<Item> AGRULITE_ARMOR_CHESTPLATE = REGISTRY.register("agrulite_armor_chestplate",
			() -> new AgruliteArmorItem.Chestplate());
	public static final RegistryObject<Item> AGRULITE_ARMOR_LEGGINGS = REGISTRY.register("agrulite_armor_leggings",
			() -> new AgruliteArmorItem.Leggings());
	public static final RegistryObject<Item> AGRULITE_ARMOR_BOOTS = REGISTRY.register("agrulite_armor_boots", () -> new AgruliteArmorItem.Boots());
	public static final RegistryObject<Item> ENDERFLUPS = block(UnderNetherNeverackModBlocks.ENDERFLUPS, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> ENDER = REGISTRY.register("ender_spawn_egg",
			() -> new ForgeSpawnEggItem(UnderNetherNeverackModEntities.ENDER, -16751104, -6750055,
					new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
