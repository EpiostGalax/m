
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.undernetherneverack.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.common.BasicItemListing;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.npc.VillagerProfession;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.FORGE)
public class UnderNetherNeverackModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == VillagerProfession.ARMORER) {
			event.getTrades().get(1)
					.add(new BasicItemListing(new ItemStack(UnderNetherNeverackModItems.SAPHIR.get(), 6),
							new ItemStack(UnderNetherNeverackModItems.SAPHIR_ARMOR_HELMET.get()),
							new ItemStack(UnderNetherNeverackModItems.AIGUE_MARINA.get()), 10, 15, 0.05f));
		}
	}
}
