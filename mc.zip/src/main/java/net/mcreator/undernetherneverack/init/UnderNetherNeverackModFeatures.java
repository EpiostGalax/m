
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.undernetherneverack.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.world.BiomeLoadingEvent;

import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Holder;

import net.mcreator.undernetherneverack.world.features.ores.Yellow_saphireOreFeature;
import net.mcreator.undernetherneverack.world.features.ores.SaphirOreFeature;
import net.mcreator.undernetherneverack.world.features.ores.RubyOreFeature;
import net.mcreator.undernetherneverack.world.features.ores.CoraleumOreFeature;
import net.mcreator.undernetherneverack.world.features.ores.Aigue_marinaOreFeature;
import net.mcreator.undernetherneverack.world.features.ores.AgruliteOreFeature;
import net.mcreator.undernetherneverack.UnderNetherNeverackMod;

import java.util.function.Supplier;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber
public class UnderNetherNeverackModFeatures {
	public static final DeferredRegister<Feature<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.FEATURES, UnderNetherNeverackMod.MODID);
	private static final List<FeatureRegistration> FEATURE_REGISTRATIONS = new ArrayList<>();
	public static final RegistryObject<Feature<?>> SAPHIR_ORE = register("saphir_ore", SaphirOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, SaphirOreFeature.GENERATE_BIOMES, SaphirOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> RUBY_ORE = register("ruby_ore", RubyOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, RubyOreFeature.GENERATE_BIOMES, RubyOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> YELLOW_SAPHIRE_ORE = register("yellow_saphire_ore", Yellow_saphireOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, Yellow_saphireOreFeature.GENERATE_BIOMES,
					Yellow_saphireOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> AIGUE_MARINA_ORE = register("aigue_marina_ore", Aigue_marinaOreFeature::feature,
			new FeatureRegistration(GenerationStep.Decoration.UNDERGROUND_ORES, Aigue_marinaOreFeature.GENERATE_BIOMES,
					Aigue_marinaOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> CORALEUM_ORE = register("coraleum_ore", CoraleumOreFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_ORES, CoraleumOreFeature.GENERATE_BIOMES, CoraleumOreFeature::placedFeature));
	public static final RegistryObject<Feature<?>> AGRULITE_ORE = register("agrulite_ore", AgruliteOreFeature::feature, new FeatureRegistration(
			GenerationStep.Decoration.UNDERGROUND_ORES, AgruliteOreFeature.GENERATE_BIOMES, AgruliteOreFeature::placedFeature));

	private static RegistryObject<Feature<?>> register(String registryname, Supplier<Feature<?>> feature, FeatureRegistration featureRegistration) {
		FEATURE_REGISTRATIONS.add(featureRegistration);
		return REGISTRY.register(registryname, feature);
	}

	@SubscribeEvent
	public static void addFeaturesToBiomes(BiomeLoadingEvent event) {
		for (FeatureRegistration registration : FEATURE_REGISTRATIONS) {
			if (registration.biomes() == null || registration.biomes().contains(event.getName()))
				event.getGeneration().getFeatures(registration.stage()).add(registration.placedFeature().get());
		}
	}

	private static record FeatureRegistration(GenerationStep.Decoration stage, Set<ResourceLocation> biomes,
			Supplier<Holder<PlacedFeature>> placedFeature) {
	}
}
