
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.undernetherneverack.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.undernetherneverack.block.Yellow_saphireOreBlock;
import net.mcreator.undernetherneverack.block.Yellow_saphireBlockBlock;
import net.mcreator.undernetherneverack.block.SaphirOreBlock;
import net.mcreator.undernetherneverack.block.SaphirBlockBlock;
import net.mcreator.undernetherneverack.block.RubyOreBlock;
import net.mcreator.undernetherneverack.block.RubyBlockBlock;
import net.mcreator.undernetherneverack.block.EnderflupsBlock;
import net.mcreator.undernetherneverack.block.CoraleumOreBlock;
import net.mcreator.undernetherneverack.block.CoraleumBlockBlock;
import net.mcreator.undernetherneverack.block.Aigue_marinaOreBlock;
import net.mcreator.undernetherneverack.block.Aigue_marinaBlockBlock;
import net.mcreator.undernetherneverack.block.AgruliteOreBlock;
import net.mcreator.undernetherneverack.block.AgruliteBlockBlock;
import net.mcreator.undernetherneverack.UnderNetherNeverackMod;

public class UnderNetherNeverackModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, UnderNetherNeverackMod.MODID);
	public static final RegistryObject<Block> SAPHIR_ORE = REGISTRY.register("saphir_ore", () -> new SaphirOreBlock());
	public static final RegistryObject<Block> SAPHIR_BLOCK = REGISTRY.register("saphir_block", () -> new SaphirBlockBlock());
	public static final RegistryObject<Block> RUBY_ORE = REGISTRY.register("ruby_ore", () -> new RubyOreBlock());
	public static final RegistryObject<Block> RUBY_BLOCK = REGISTRY.register("ruby_block", () -> new RubyBlockBlock());
	public static final RegistryObject<Block> YELLOW_SAPHIRE_ORE = REGISTRY.register("yellow_saphire_ore", () -> new Yellow_saphireOreBlock());
	public static final RegistryObject<Block> YELLOW_SAPHIRE_BLOCK = REGISTRY.register("yellow_saphire_block", () -> new Yellow_saphireBlockBlock());
	public static final RegistryObject<Block> AIGUE_MARINA_ORE = REGISTRY.register("aigue_marina_ore", () -> new Aigue_marinaOreBlock());
	public static final RegistryObject<Block> AIGUE_MARINA_BLOCK = REGISTRY.register("aigue_marina_block", () -> new Aigue_marinaBlockBlock());
	public static final RegistryObject<Block> CORALEUM_ORE = REGISTRY.register("coraleum_ore", () -> new CoraleumOreBlock());
	public static final RegistryObject<Block> CORALEUM_BLOCK = REGISTRY.register("coraleum_block", () -> new CoraleumBlockBlock());
	public static final RegistryObject<Block> AGRULITE_ORE = REGISTRY.register("agrulite_ore", () -> new AgruliteOreBlock());
	public static final RegistryObject<Block> AGRULITE_BLOCK = REGISTRY.register("agrulite_block", () -> new AgruliteBlockBlock());
	public static final RegistryObject<Block> ENDERFLUPS = REGISTRY.register("enderflups", () -> new EnderflupsBlock());
}
